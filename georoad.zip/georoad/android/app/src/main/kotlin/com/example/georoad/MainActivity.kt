package com.example.georoad

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
