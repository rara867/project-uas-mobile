import 'dart:io';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import '../services/geo_services.dart';
import 'history_page.dart'; // Import halaman riwayat yang akan kita buat

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final GeoService _geoService = GeoService();
  final TextEditingController _descriptionController = TextEditingController();

  File? _image;
  Position? _location;
  String _address = "Ambil foto untuk mendapatkan lokasi dan alamat";
  bool _isProcessing = false;
  bool _isSending = false;

  void _handlePickData() async {
    setState(() {
      _isProcessing = true;
      _address = "Sedang memproses lokasi...";
    });

    try {
      final photo = await _geoService.takePhoto();
      if (photo != null) {
        final loc = await _geoService.getCurrentLocation();
        if (loc != null) {
          final addressName = await _geoService.getAddressFromLatLng(
            loc.latitude,
            loc.longitude,
          );
          setState(() {
            _image = photo;
            _location = loc;
            _address = addressName;
          });
        }
      }
    } catch (e) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text("Error: $e")));
    } finally {
      setState(() => _isProcessing = false);
    }
  }

  void _sendReport() async {
    if (_image == null || _location == null) return;

    if (_descriptionController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Harap isi deskripsi kerusakan.")),
      );
      return;
    }

    setState(() => _isSending = true);

    final success = await _geoService.uploadReport(
      _image!,
      _location!.latitude,
      _location!.longitude,
      _descriptionController.text,
    );

    setState(() => _isSending = false);

    if (success) {
      _showSuccessDialog();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            "Gagal mengirim laporan. Pastikan Server & Wi-Fi aktif!",
          ),
        ),
      );
    }
  }

  void _showSuccessDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: const Row(
          children: [
            Icon(Icons.check_circle, color: Colors.green),
            SizedBox(width: 10),
            Text("Berhasil"),
          ],
        ),
        content: const Text("Laporan berhasil masuk ke database server."),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              setState(() {
                _image = null;
                _location = null;
                _descriptionController.clear();
                _address = "Ambil foto untuk mendapatkan lokasi dan alamat";
              });
            },
            child: const Text("SIAP"),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("GeoRoad"),
        backgroundColor: Colors.amber,
        centerTitle: true,
        // TAMBAHKAN TOMBOL RIWAYAT DI SINI
        actions: [
          IconButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) =>  HistoryPage()),
              );
            },
            icon: const Icon(Icons.history, color: Colors.black87),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            // Preview Foto
            GestureDetector(
              onTap: _isSending ? null : _handlePickData,
              child: Container(
                height: 250,
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Colors.grey[200],
                  borderRadius: BorderRadius.circular(15),
                  border: Border.all(color: Colors.amber.withOpacity(0.5)),
                ),
                child: _image != null
                    ? ClipRRect(
                        borderRadius: BorderRadius.circular(15),
                        child: Image.file(_image!, fit: BoxFit.cover),
                      )
                    : const Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.add_a_photo_outlined,
                            size: 60,
                            color: Colors.grey,
                          ),
                          Text(
                            "Tap untuk ambil foto",
                            style: TextStyle(color: Colors.grey),
                          ),
                        ],
                      ),
              ),
            ),
            const SizedBox(height: 20),

            // Card Alamat
            Card(
              elevation: 2,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
              child: ListTile(
                leading: const Icon(Icons.location_on, color: Colors.red),
                title: Text(_address, style: const TextStyle(fontSize: 14)),
              ),
            ),
            const SizedBox(height: 15),

            // Input Deskripsi
            if (_image != null) ...[
              TextField(
                controller: _descriptionController,
                maxLines: 3,
                enabled: !_isSending,
                decoration: InputDecoration(
                  labelText: "Deskripsi Kerusakan",
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  filled: true,
                  fillColor: Colors.white,
                ),
              ),
              const SizedBox(height: 25),

              // Tombol Kirim
              SizedBox(
                width: double.infinity,
                height: 50,
                child: _isSending
                    ? const Center(
                        child: CircularProgressIndicator(color: Colors.green),
                      )
                    : ElevatedButton.icon(
                        onPressed: _sendReport,
                        icon: const Icon(Icons.send),
                        label: const Text("KIRIM LAPORAN SEKARANG"),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.green,
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                      ),
              ),
            ] else ...[
              // Tombol Mulai
              SizedBox(
                width: double.infinity,
                height: 50,
                child: _isProcessing
                    ? const Center(
                        child: CircularProgressIndicator(color: Colors.amber),
                      )
                    : ElevatedButton.icon(
                        onPressed: _handlePickData,
                        icon: const Icon(Icons.camera_alt),
                        label: const Text("MULAI AMBIL DATA"),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.amber,
                          foregroundColor: Colors.black,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                      ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
