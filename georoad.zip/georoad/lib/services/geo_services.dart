import 'dart:io';
import 'dart:convert'; // Untuk jsonDecode
import 'package:http/http.dart' as http; // Untuk upload ke Cloudinary
import 'package:image_picker/image_picker.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class GeoService {
  final ImagePicker _picker = ImagePicker();
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // --- DATA CLOUDINARY ANDA ---
  final String cloudName = "dta99ejeo";
  final String uploadPreset = "georoad";

  // 1. Fungsi Mengambil Foto
  Future<File?> takePhoto() async {
    final XFile? pickedFile = await _picker.pickImage(
      source: ImageSource.camera,
      imageQuality: 50,
    );
    return pickedFile != null ? File(pickedFile.path) : null;
  }

  // 2. Fungsi Mengambil Koordinat GPS
  Future<Position?> getCurrentLocation() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) return null;

    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) return null;
    }
    return await Geolocator.getCurrentPosition();
  }

  // 3. Fungsi Mengubah Koordinat menjadi Nama Jalan
  Future<String> getAddressFromLatLng(double lat, double lng) async {
    try {
      List<Placemark> placemarks = await placemarkFromCoordinates(lat, lng);
      if (placemarks.isNotEmpty) {
        Placemark place = placemarks[0];
        return "${place.street}, ${place.subLocality}";
      }
      return "Alamat tidak terdeteksi";
    } catch (e) {
      return "Gagal mendapatkan nama jalan";
    }
  }

  // 4. Fungsi Mengambil Riwayat (Stream Real-time dari Firestore)
  Stream<QuerySnapshot> fetchReportsStream() {
    return _firestore
        .collection('reports')
        .orderBy('created_at', descending: true)
        .snapshots();
  }

  // 5. Fungsi Mengirim Data (Kombinasi Cloudinary + Firestore)
  Future<bool> uploadReport(
    File image,
    double lat,
    double lng,
    String desc,
  ) async {
    try {
      // --- LANGKAH A: UPLOAD KE CLOUDINARY ---
      var uri = Uri.parse(
        "https://api.cloudinary.com/v1_1/$cloudName/image/upload",
      );
      var request = http.MultipartRequest("POST", uri);

      request.fields['upload_preset'] = uploadPreset;
      request.files.add(await http.MultipartFile.fromPath('file', image.path));

      var response = await request.send();
      var responseData = await response.stream.toBytes();
      var responseString = String.fromCharCodes(responseData);
      var jsonResponse = jsonDecode(responseString);

      if (response.statusCode == 200 || response.statusCode == 201) {
        // Ambil URL gambar hasil upload dari Cloudinary
        String imageUrl = jsonResponse['secure_url'];

        // --- LANGKAH B: SIMPAN URL KE FIRESTORE ---
        await _firestore.collection('reports').add({
          'latitude': lat,
          'longitude': lng,
          'description': desc,
          'image_url': imageUrl, // Simpan link Cloudinary di sini
          'created_at': FieldValue.serverTimestamp(),
        });

        print("Berhasil! Gambar di Cloudinary, Data di Firestore.");
        return true;
      } else {
        print("Gagal Upload ke Cloudinary: ${response.statusCode}");
        return false;
      }
    } catch (e) {
      print("Error Upload Report: $e");
      return false;
    }
  }
}
